// middleware.ts
//
// 🧠 WHAT IS MIDDLEWARE?
// Middleware is code that runs on EVERY request, BEFORE the page loads.
// Think of it as a security guard at the front door.
//
// Here's what it does:
// 1. A user visits /dashboard
// 2. Middleware runs first and checks: "Is this user logged in?"
// 3. If YES → let them through to the dashboard
// 4. If NO → redirect them to /auth/login
//
// This prevents unauthorized users from ever seeing protected pages.
// The beautiful thing is: you protect pages in ONE place here,
// instead of checking auth on every single page separately.

import { createServerClient } from "@supabase/ssr";
import { NextResponse, type NextRequest } from "next/server";

// 🧠 These are the routes that REQUIRE a user to be logged in.
// Add more routes here as you build protected features.
const PROTECTED_ROUTES = [
  "/dashboard",
  "/admin",
];

// 🧠 These are routes only for logged-OUT users.
// If a logged-in user visits /auth/login, send them to /dashboard.
const AUTH_ROUTES = ["/auth/login", "/auth/signup"];

export async function middleware(request: NextRequest) {
  let supabaseResponse = NextResponse.next({
    request,
  });

  const supabase = createServerClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        getAll() {
          return request.cookies.getAll();
        },
        setAll(cookiesToSet) {
          cookiesToSet.forEach(({ name, value }) =>
            request.cookies.set(name, value)
          );
          supabaseResponse = NextResponse.next({ request });
          cookiesToSet.forEach(({ name, value, options }) =>
            supabaseResponse.cookies.set(name, value, options)
          );
        },
      },
    }
  );

  // Get the current user (this refreshes the session if needed)
  const {
    data: { user },
  } = await supabase.auth.getUser();

  const { pathname } = request.nextUrl;

  // Check if this is a protected route
  const isProtectedRoute = PROTECTED_ROUTES.some((route) =>
    pathname.startsWith(route)
  );

  // Check if this is an auth-only route (login/signup)
  const isAuthRoute = AUTH_ROUTES.some((route) =>
    pathname.startsWith(route)
  );

  // If trying to access a protected route without being logged in
  if (isProtectedRoute && !user) {
    const redirectUrl = new URL("/auth/login", request.url);
    redirectUrl.searchParams.set("redirectTo", pathname); // Remember where they were going
    return NextResponse.redirect(redirectUrl);
  }

  // If already logged in and trying to access login/signup
  if (isAuthRoute && user) {
    return NextResponse.redirect(new URL("/dashboard", request.url));
  }

  return supabaseResponse;
}

// 🧠 This tells Next.js which URLs the middleware should run on.
// The pattern here runs it on all pages EXCEPT:
// - _next (Next.js internal files)
// - Static files (images, favicon, etc.)
// - API routes (they handle their own auth)
export const config = {
  matcher: [
    "/((?!_next/static|_next/image|favicon.ico|images/|icons/|api/).*)",
  ],
};
