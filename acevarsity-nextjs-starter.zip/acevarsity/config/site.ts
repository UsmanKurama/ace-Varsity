// config/site.ts
// Single source of truth for all site-wide configuration.
// Change values here and they update everywhere.

export const SITE_CONFIG = {
  name:        "Ace Varsity",
  tagline:     "Nigeria's #1 EdTech Platform",
  url:         "https://acevarsity.com.ng",
  description: "Access past questions, CBT practice exams, handouts, and study resources for all Nigerian universities.",
  ogImage:     "https://acevarsity.com.ng/images/og-image.jpg",
  gtmId:       "GTM-TN23C3PH", // Your existing Google Tag Manager ID

  social: {
    twitter:   "https://twitter.com/acevarsity",
    instagram: "https://instagram.com/acevarsity",
    facebook:  "https://facebook.com/acevarsity",
  },

  contact: {
    email:   "support@acevarsity.com.ng",
    subject: "support@acevarsity.com.ng",
  },
} as const;

// Your navigation structure — matches your existing navbar exactly
export const NAV_LINKS = [
  {
    label: "Resources",
    href:  "/resources",
    children: [
      { label: "Academic Calendar",  href: "/academic-calendar",  icon: "calendar" },
      { label: "GST CBT",            href: "/cbt/gst-cbt",        icon: "file-text" },
      { label: "JAMB Syllabus",      href: "/jamb-syllabus",      icon: "scroll" },
      { label: "JAMB CBT",           href: "/cbt/jamb-cbt",       icon: "monitor" },
      { label: "Past Questions",     href: "/jamb-past-questions", icon: "file-alt" },
      { label: "Newspaper Directory",href: "/newspaper",           icon: "newspaper" },
    ],
  },
  { label: "Social",     href: "/social" },
  { label: "Contribute", href: "/contribute" },
  { label: "Contact",    href: "/contact" },
  { label: "About",      href: "/about" },
] as const;

// Pages that require user to be logged in
export const PROTECTED_ROUTES = [
  "/dashboard",
  "/admin",
] as const;

// Quick access tools shown on homepage (from your quickResources array)
export const QUICK_RESOURCES = [
  {
    title: "Academic Calendar",
    icon:  "calendar-alt",
    desc:  "Official university schedule, semester deadlines & holidays.",
    href:  "/academic-calendar",
    color: "#1E3A8A",
  },
  {
    title: "JAMB Syllabus",
    icon:  "scroll",
    desc:  "Complete UTME syllabus with topic-by-topic breakdown.",
    href:  "/jamb-syllabus",
    color: "#F59E0B",
  },
  {
    title: "JAMB Past Questions",
    icon:  "file-alt",
    desc:  "Study real past papers & CBT practice.",
    href:  "/jamb-past-questions",
    color: "#10B981",
  },
  {
    title: "GST Study Pack",
    icon:  "university",
    desc:  "GST 101-202: Nigerian peoples & culture.",
    href:  "/cbt/gst-cbt",
    color: "#8B5CF6",
  },
  {
    title: "Self Improvement",
    icon:  "brain",
    desc:  "E-books on productivity, leadership & mindset.",
    href:  "/self-improvement",
    color: "#14B8A6",
  },
  {
    title: "Nigerian Newspaper Directory",
    icon:  "newspaper",
    desc:  "Your complete guide to all major Nigerian newspapers.",
    href:  "/newspaper",
    color: "#17434b",
  },
] as const;

// Stats shown on homepage counter section (matches your existing data-target values)
export const HOMEPAGE_STATS = [
  { value: 50000, suffix: "+", label: "Past Questions" },
  { value: 500,   suffix: "+", label: "CBT Exams" },
  { value: 150,   suffix: "+", label: "Universities" },
  { value: 10000, suffix: "+", label: "Active Students" },
] as const;

// Testimonials (matches your existing testimonialsData array)
export const TESTIMONIALS = [
  {
    name:  "Amina Bello",
    title: "UNIMAID, Comp. Sci.",
    text:  "Ace Varsity transformed my exam preparation. The CBT simulator is exactly like the real thing!",
  },
  {
    name:  "Ibrahim Suleiman",
    title: "ABU Zaria, Engineering",
    text:  "The past questions database is incredibly comprehensive. I found materials from 2000 to 2024!",
  },
  {
    name:  "Fatima Usman",
    title: "JAMB Aspirant",
    text:  "JAMB prep has never been easier. The detailed explanations helped me understand concepts deeply.",
  },
] as const;
