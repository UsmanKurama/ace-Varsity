# Ace Varsity — Next.js Migration

Nigeria's #1 EdTech Platform — migrated from static HTML/CSS/JS to Next.js 15 + Supabase.

---

## Complete Page Inventory (36 pages discovered from source code)

### Public Pages
| Old HTML File | New Next.js Route | Status |
|---|---|---|
| index.html | / | 🔄 Phase 1 |
| about.html | /about | 🔄 Phase 1 |
| contact.html | /contact | 🔄 Phase 1 |
| contribute.html | /contribute | 🔄 Phase 1 |
| social.html | /social | 🔄 Phase 1 |
| blog.html | /blog | 🔄 Phase 1 |
| blog-view.html | /blog/[slug] | 🔄 Phase 1 |
| newspaper.html | /newspaper | 🔄 Phase 1 |
| partners.html | /partners | 🔄 Phase 1 |
| course-request.html | /course-request | 🔄 Phase 1 |
| gpa-calculator.html | /gpa-calculator | 🔄 Phase 2 |
| academic-calendar.html | /academic-calendar | 🔄 Phase 2 |
| self-improvement-books.html | /self-improvement | 🔄 Phase 2 |
| view-Pdf.html | /view-pdf | 🔄 Phase 2 |

### JAMB Pages
| Old HTML File | New Next.js Route | Status |
|---|---|---|
| jamb-material.html | /jamb-material | 🔄 Phase 1 |
| Jamb-syllabus.html | /jamb-syllabus | 🔄 Phase 2 |
| jamb-past-questions.html | /jamb-past-questions | 🔄 Phase 2 |
| assets/jamb-materials/syllabus/biology.html | /jamb-syllabus/biology | 🔄 Phase 2 |
| (+ 13 other syllabus subjects) | /jamb-syllabus/[subject] | 🔄 Phase 2 |

### CBT Pages
| Old HTML File | New Next.js Route | Status |
|---|---|---|
| cbt/jamb-cbt.html | /cbt/jamb-cbt | 🔄 Phase 4 |
| cbt/GST-cbt.html | /cbt/gst-cbt | 🔄 Phase 4 |
| cbt/cbt-practice.html | /cbt/practice | 🔄 Phase 4 |
| Demo.html | /cbt/demo | 🔄 Phase 4 |

### Auth Pages
| Old HTML File | New Next.js Route | Status |
|---|---|---|
| pages/auth/login.html | /auth/login | 🔄 Phase 3 |
| pages/auth/signup.html | /auth/signup | 🔄 Phase 3 |
| pages/auth/reset-password.html | /auth/reset-password | 🔄 Phase 3 |
| pages/auth/dashboard.html | /dashboard | 🔄 Phase 3 |
| pages/auth/profile.html | /dashboard/profile | 🔄 Phase 3 |

### Resources
| Old HTML File | New Next.js Route | Status |
|---|---|---|
| resources.html | /resources | 🔄 Phase 2 |

### Legal & Policy Pages
| Old HTML File | New Next.js Route | Status |
|---|---|---|
| pages/Policy.html | /pages/privacy | 🔄 Phase 1 |
| pages/terms.html | /pages/terms | 🔄 Phase 1 |
| pages/disclaimer.html | /pages/disclaimer | 🔄 Phase 1 |
| pages/copyright-Policy.html | /pages/copyright | 🔄 Phase 1 |
| pages/Accessibility.html | /pages/accessibility | 🔄 Phase 1 |
| pages/help.html | /pages/help | 🔄 Phase 1 |
| pages/report.html | /pages/report | 🔄 Phase 1 |
| 404.html | app/not-found.tsx | ✅ Done |

### Admin (New — doesn't exist in old site)
| Route | Purpose | Status |
|---|---|---|
| /admin | Admin dashboard | 🔄 Phase 6 |
| /admin/courses | Manage courses | 🔄 Phase 6 |
| /admin/questions | Manage CBT questions | 🔄 Phase 6 |
| /admin/users | Manage users | 🔄 Phase 6 |
| /admin/analytics | Analytics dashboard | 🔄 Phase 6 |

---

## Migration Phases

### Phase 1 — Foundation (Weeks 1–2)
- [x] Next.js project setup with TypeScript + Tailwind
- [x] Exact brand colors preserved (#1E3A8A blue, #F59E0B gold)
- [x] Navbar with existing links + dark mode toggle
- [x] Footer with all existing links
- [x] Homepage (all 7 sections)
- [ ] About page
- [ ] Contact page
- [ ] Blog listing + article pages
- [ ] All 7 legal/policy pages
- [ ] Deploy to Vercel (domain switch from Netlify)

### Phase 2 — Database & Content (Weeks 3–4)
- [ ] Set up Supabase project
- [ ] Create database tables (courses, questions, materials, etc.)
- [ ] Connect Resources page to real data
- [ ] JAMB pages with real data
- [ ] Syllabus pages (14 subjects as dynamic routes)
- [ ] GPA Calculator (convert existing JS logic)
- [ ] Academic Calendar
- [ ] PDF Viewer

### Phase 3 — Authentication (Weeks 5–6)
- [x] Login page (matching existing design)
- [x] Signup page (with Nigerian university selector)
- [x] Reset password
- [ ] OAuth callback route
- [ ] Dashboard (convert existing dashboard.html)
- [ ] Profile page
- [ ] Auth middleware (route protection)

### Phase 4 — CBT Engine (Weeks 7–9)
- [ ] JAMB CBT (convert jamb-cbt.html)
- [ ] GST CBT (convert GST-cbt.html)
- [ ] Question engine (from quiz-engine.js)
- [ ] Timer, scoring, results
- [ ] Save results to Supabase

### Phase 5 — Payments (Weeks 10–12)
- [ ] Paystack integration
- [ ] Premium content gating
- [ ] Subscription management

### Phase 6 — Admin & AI (Weeks 13–16)
- [ ] Admin dashboard
- [ ] Content management
- [ ] AI study assistant
- [ ] Analytics

---

## Key Technical Decisions

### Why the Supabase keys in auth.js are wrong
Your current `auth.js` has:
```js
const SUPABASE_ANON_KEY = 'https://hkwbtcnldhprvdgljhiz.supabase.co'; // ← This is wrong, it's the URL not the key
const supabase = window.supabase.createClient(https://..., https://...); // ← Syntax error
```
This is why auth doesn't work on the current site. In the Next.js version, we fix this properly with environment variables.

### Dark Mode
Your existing dark mode uses `localStorage.setItem("unimaidDarkMode", "enabled")`.
The new ThemeProvider reads that same key, so existing users keep their preference.

### URL Structure
Old: `/pages/auth/login.html` → New: `/auth/login`
Old: `/jamb-material.html` → New: `/jamb-material`
Redirects in next.config.ts handle old URLs automatically.

---

## Getting Started

```bash
# 1. Install dependencies
npm install

# 2. Set up environment variables
cp .env.local.example .env.local
# Fill in your Supabase URL and keys

# 3. Start development server
npm run dev

# 4. Open in browser
# http://localhost:3000
```
