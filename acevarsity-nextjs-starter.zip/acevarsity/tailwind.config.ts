// tailwind.config.ts
//
// 🧠 WHAT IS THIS?
// This configures Tailwind CSS for your project.
// The most important part is "content" — it tells Tailwind
// which files to scan so it only generates CSS classes you actually use.
// The "theme" section adds your Ace Varsity brand colors as Tailwind classes,
// so you can write className="text-brand-gold" instead of inline styles.

import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  
  // 🧠 darkMode: "class" means dark mode is controlled by adding
  // a class to the <html> element (data-theme="dark" in your current site,
  // or the "dark" class in Tailwind's convention).
  darkMode: "class",
  
  theme: {
    extend: {
      // Your exact Ace Varsity brand colors as Tailwind utilities
      colors: {
        brand: {
          blue:       "#1E3A8A",  // --primary-blue
          "blue-dark":"#152c6b",
          gold:       "#F59E0B",  // --primary-gold
          "gold-dark":"#D97706",  // --primary-gold-dark
          "gold-light":"#FBBF24", // --primary-gold-light
          purple:     "#8B5CF6",  // --cbt-purple
          teal:       "#14B8A6",  // --accent-teal
          green:      "#10B981",  // --success-green
          red:        "#EF4444",  // --error-red
        },
      },
      
      // Your brand fonts
      fontFamily: {
        sans:    ["Inter", "system-ui", "sans-serif"],
        heading: ["Poppins", "system-ui", "sans-serif"],
      },
      
      // Extra border radius values matching your CSS variables
      borderRadius: {
        "2xl": "1rem",
        "3xl": "1.5rem",
      },
      
      // Extra box shadows matching your --shadow-* variables
      boxShadow: {
        card: "0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1)",
      },
      
      // Animation for the marquee (universities banner)
      animation: {
        marquee: "marquee 30s linear infinite",
        "fade-in-up": "fadeInUp 0.5s ease-out",
        "spin-slow": "spin 3s linear infinite",
      },
      
      keyframes: {
        marquee: {
          "0%":   { transform: "translateX(0)" },
          "100%": { transform: "translateX(-50%)" },
        },
        fadeInUp: {
          "0%":   { opacity: "0", transform: "translateY(20px)" },
          "100%": { opacity: "1", transform: "translateY(0)" },
        },
      },
    },
  },
  plugins: [],
};

export default config;
