// app/page.tsx
//
// 🧠 WHAT IS THIS FILE?
// This is your HOMEPAGE — what people see at acevarsity.com.ng
// In Next.js App Router, every folder with a "page.tsx" becomes a URL.
// This file lives at the root "app/" folder, so it maps to "/"
//
// 🧠 WHY IS THERE NO "export default function Home() { return <div>Hello</div> }" BOILERPLATE?
// We're importing sections as separate components and composing them here.
// This keeps each section maintainable — you can edit the hero without
// touching the features section, for example.

import HeroSection from "@/components/home/HeroSection";
import FeaturesSection from "@/components/home/FeaturesSection";
import StatsSection from "@/components/home/StatsSection";
import TestimonialsSection from "@/components/home/TestimonialsSection";
import NewsletterSection from "@/components/home/NewsletterSection";
import UniversitiesMarquee from "@/components/home/UniversitiesMarquee";
import type { Metadata } from "next";

// This overrides the root layout's metadata for this specific page
export const metadata: Metadata = {
  title: "Nigeria's #1 EdTech Platform | Ace Varsity",
  description:
    "Access past questions, CBT simulations, handouts, and study resources from all Nigerian universities. Join thousands of students already acing their exams.",
};

// 🧠 THIS IS A SERVER COMPONENT
// By default in Next.js App Router, all components are "Server Components".
// That means this code runs on the server (Vercel's servers), not in the browser.
// This is GREAT for SEO and performance — the page arrives pre-built to the user.
// You'll learn when to use "use client" (browser components) vs server components.
export default function HomePage() {
  return (
    <>
      <HeroSection />
      <StatsSection />
      <FeaturesSection />
      <TestimonialsSection />
      <UniversitiesMarquee />
      <NewsletterSection />
    </>
  );
}
