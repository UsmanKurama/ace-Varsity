// app/resources/page.tsx
//
// 🧠 This is a SERVER COMPONENT that will eventually fetch courses
// from Supabase on the server before sending the page to the user.
// For now it shows the page structure with placeholder content.

import type { Metadata } from "next";
import { BookOpen, Users, Layers, GraduationCap } from "lucide-react";
import ResourceFilter from "@/components/resources/ResourceFilter";
import CourseGrid from "@/components/resources/CourseGrid";

export const metadata: Metadata = {
  title: "Academic Resource Library",
  description:
    "Access complete course materials, past questions, handouts, and lecture notes for all UNIMAID faculties and departments.",
};

// 🧠 WHAT ARE searchParams?
// When a URL has filters like /resources?faculty=science&level=300
// Next.js passes those values here automatically as searchParams.
// We use them to filter which courses to show.
type SearchParams = Promise<{
  faculty?: string;
  level?: string;
  search?: string;
  university?: string;
}>;

export default async function ResourcesPage({
  searchParams,
}: {
  searchParams: SearchParams;
}) {
  const params = await searchParams;

  // These are the stats shown at the top of the page
  // Later these will come from real Supabase queries
  const stats = [
    { icon: BookOpen, value: "500+", label: "Total Courses" },
    { icon: Layers, value: "12", label: "Faculties" },
    { icon: GraduationCap, value: "6", label: "Levels" },
    { icon: Users, value: "20+", label: "Departments" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">

      {/* Page Header */}
      <div className="bg-white border-b border-gray-200 pt-24 pb-10">
        <div className="container-main">
          <h1 className="text-3xl md:text-4xl font-bold text-gray-900 mb-3">
            Academic Resource Library
          </h1>
          <p className="text-gray-500 max-w-2xl">
            Access complete course materials, past questions, handouts, and
            lecture notes for all faculties and departments.
          </p>

          {/* Stats row */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-8">
            {stats.map(({ icon: Icon, value, label }) => (
              <div
                key={label}
                className="flex items-center gap-3 p-4 bg-gray-50 rounded-xl"
              >
                <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Icon className="w-5 h-5 text-blue-600" />
                </div>
                <div>
                  <div className="text-xl font-bold text-gray-900">{value}</div>
                  <div className="text-xs text-gray-500">{label}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Filter + Results */}
      <div className="container-main py-8">
        <div className="flex flex-col lg:flex-row gap-6">

          {/* Sidebar Filters */}
          <aside className="lg:w-64 flex-shrink-0">
            <ResourceFilter currentParams={params} />
          </aside>

          {/* Course Grid */}
          <main className="flex-1">
            <CourseGrid filters={params} />
          </main>
        </div>
      </div>
    </div>
  );
}
