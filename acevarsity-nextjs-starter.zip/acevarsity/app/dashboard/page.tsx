// app/dashboard/page.tsx
//
// 🧠 This is a PROTECTED page — only logged-in users can see it.
// The middleware.ts file handles that protection automatically.
// By the time this code runs, we KNOW the user is logged in.

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";
import { BookOpen, Award, Clock, TrendingUp } from "lucide-react";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Student Dashboard",
};

export default async function DashboardPage() {
  const supabase = await createClient();

  // Get the currently logged-in user
  const {
    data: { user },
  } = await supabase.auth.getUser();

  // Extra safety check (middleware handles the main redirect)
  if (!user) {
    redirect("/auth/login");
  }

  // Get the user's profile from our profiles table
  const { data: profile } = await supabase
    .from("profiles")
    .select("*")
    .eq("user_id", user.id)
    .single();

  // Get the user's recent CBT results
  const { data: recentResults } = await supabase
    .from("cbt_results")
    .select("*")
    .eq("user_id", user.id)
    .order("created_at", { ascending: false })
    .limit(5);

  const firstName = profile?.full_name?.split(" ")[0] ?? user.email?.split("@")[0] ?? "Student";

  const QUICK_STATS = [
    {
      icon: BookOpen,
      label: "Exams Taken",
      value: recentResults?.length ?? 0,
      color: "bg-blue-100 text-blue-600",
    },
    {
      icon: Award,
      label: "Best Score",
      value: recentResults?.length
        ? `${Math.max(...recentResults.map((r) => Math.round((r.score / r.total) * 100)))}%`
        : "—",
      color: "bg-green-100 text-green-600",
    },
    {
      icon: Clock,
      label: "Study Hours",
      value: "Coming soon",
      color: "bg-purple-100 text-purple-600",
    },
    {
      icon: TrendingUp,
      label: "Avg Score",
      value: recentResults?.length
        ? `${Math.round(recentResults.reduce((a, r) => a + (r.score / r.total) * 100, 0) / recentResults.length)}%`
        : "—",
      color: "bg-amber-100 text-amber-600",
    },
  ];

  return (
    <div className="min-h-screen bg-gray-50 pt-20">
      <div className="container-main py-8">

        {/* Welcome header */}
        <div className="mb-8">
          <h1 className="text-2xl font-bold text-gray-900">
            Welcome back, {firstName}! 👋
          </h1>
          <p className="text-gray-500 mt-1">
            {profile?.is_premium
              ? "Premium member — full access enabled"
              : "Free account — upgrade for full access"}
          </p>
        </div>

        {/* Quick stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {QUICK_STATS.map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="card p-5">
              <div
                className={`w-10 h-10 rounded-xl flex items-center justify-center mb-3 ${color}`}
              >
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-xl font-bold text-gray-900">{value}</div>
              <div className="text-sm text-gray-500 mt-0.5">{label}</div>
            </div>
          ))}
        </div>

        {/* Recent CBT results */}
        <div className="card p-6">
          <h2 className="font-semibold text-gray-900 mb-4">Recent CBT Results</h2>
          {recentResults && recentResults.length > 0 ? (
            <div className="space-y-3">
              {recentResults.map((result) => {
                const percentage = Math.round((result.score / result.total) * 100);
                return (
                  <div
                    key={result.id}
                    className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
                  >
                    <div>
                      <div className="font-medium text-gray-900 text-sm">
                        {result.exam_type} {result.subject && `— ${result.subject}`}
                      </div>
                      <div className="text-xs text-gray-500">
                        {result.score}/{result.total} questions correct
                      </div>
                    </div>
                    <div
                      className={`text-lg font-bold ${
                        percentage >= 50 ? "text-green-600" : "text-red-500"
                      }`}
                    >
                      {percentage}%
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="text-center py-8 text-gray-400">
              <BookOpen className="w-10 h-10 mx-auto mb-3 opacity-40" />
              <p className="text-sm">No exams taken yet</p>
              <a href="/cbt/jamb-cbt" className="btn-primary mt-4 text-sm py-2 px-4 inline-flex">
                Take Your First CBT
              </a>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
