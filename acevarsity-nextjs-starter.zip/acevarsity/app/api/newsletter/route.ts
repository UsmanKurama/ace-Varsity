// app/api/newsletter/route.ts
//
// 🧠 WHAT IS AN API ROUTE?
// This file creates a real backend API endpoint at:
// POST https://acevarsity.com.ng/api/newsletter
//
// When the newsletter form on the homepage submits,
// it sends the email here. This code runs on the server,
// saves the email to Supabase, and responds with success or error.
//
// "POST" means it receives data (an email address).
// "GET" would be for fetching data.

import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function POST(request: Request) {
  try {
    const { email } = await request.json();

    // Basic validation
    if (!email || !email.includes("@")) {
      return NextResponse.json(
        { error: "Please provide a valid email address." },
        { status: 400 } // 400 = Bad Request
      );
    }

    const supabase = await createClient();

    // Save to Supabase newsletter_subscribers table
    const { error } = await supabase
      .from("newsletter_subscribers")
      .insert({ email: email.toLowerCase().trim() });

    if (error) {
      // If email already exists (duplicate), give friendly message
      if (error.code === "23505") {
        return NextResponse.json(
          { message: "You're already subscribed!" },
          { status: 200 }
        );
      }
      throw error;
    }

    return NextResponse.json(
      { message: "Successfully subscribed!" },
      { status: 200 }
    );
  } catch (error) {
    console.error("Newsletter subscription error:", error);
    return NextResponse.json(
      { error: "Something went wrong. Please try again." },
      { status: 500 } // 500 = Server Error
    );
  }
}
