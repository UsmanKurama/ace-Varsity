// app/jamb-material/page.tsx

import type { Metadata } from "next";
import Link from "next/link";
import {
  BookOpen,
  FileText,
  Monitor,
  ArrowRight,
  CheckCircle2,
  Star,
  Clock,
  Target,
} from "lucide-react";

export const metadata: Metadata = {
  title: "JAMB Materials Hub",
  description:
    "Your complete preparation toolkit for UTME success. Access past questions, syllabus, and CBT practice exams all in one place.",
};

const JAMB_STATS = [
  { value: "2,500+", label: "Past Questions" },
  { value: "7", label: "Subjects" },
  { value: "120+", label: "Topics" },
  { value: "15", label: "CBT Exams" },
];

const RESOURCES = [
  {
    icon: BookOpen,
    title: "JAMB Past Questions",
    description:
      "Access thousands of verified JAMB past questions with detailed answers and explanations across all subjects.",
    href: "/jamb-past-questions",
    color: "blue",
    features: ["2,500+ questions", "With explanations", "Yearly breakdown"],
  },
  {
    icon: FileText,
    title: "JAMB Syllabus",
    description:
      "Download the complete JAMB syllabus for all subjects. Know exactly what to study for UTME success.",
    href: "/jamb-syllabus",
    color: "purple",
    features: ["All 7 subjects", "Official syllabus", "Free PDF download"],
  },
  {
    icon: Monitor,
    title: "CBT Simulator",
    description:
      "Experience real exam conditions with timed JAMB CBT practice. Get instant results and detailed explanations.",
    href: "/cbt/jamb-cbt",
    color: "green",
    features: ["15 full mock exams", "Timed practice", "Instant scoring"],
  },
];

const TIPS = [
  { icon: Target, tip: "Focus on your 4 chosen subjects and ignore the rest" },
  { icon: Clock, tip: "Practice with timed CBT exams to build speed" },
  { icon: BookOpen, tip: "Study past questions from the last 5 years heavily" },
  { icon: Star, tip: "Aim for 60+ in each subject for a score above 250" },
];

const colorMap: Record<string, string> = {
  blue: "bg-blue-100 text-blue-600",
  purple: "bg-purple-100 text-purple-600",
  green: "bg-green-100 text-green-600",
};

const btnColorMap: Record<string, string> = {
  blue: "bg-blue-600 hover:bg-blue-700 text-white",
  purple: "bg-purple-600 hover:bg-purple-700 text-white",
  green: "bg-green-600 hover:bg-green-700 text-white",
};

export default function JAMBMaterialPage() {
  return (
    <div className="min-h-screen bg-gray-50">

      {/* Page Header */}
      <div className="bg-gradient-to-br from-blue-700 to-blue-900 pt-28 pb-16 text-white">
        <div className="container-main">
          <div className="max-w-2xl">
            <span className="inline-flex items-center gap-1.5 px-3 py-1 bg-white/20 rounded-full text-sm font-medium mb-4">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              #1 JAMB Prep Platform
            </span>
            <h1 className="text-3xl md:text-4xl font-bold mb-4">
              JAMB Materials Hub
            </h1>
            <p className="text-blue-100 text-lg">
              Your complete preparation toolkit for UTME success. Access past
              questions, syllabus, and CBT practice exams all in one place.
            </p>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-10">
            {JAMB_STATS.map(({ value, label }) => (
              <div key={label} className="bg-white/10 rounded-xl p-4 text-center">
                <div className="text-2xl font-bold">{value}</div>
                <div className="text-blue-200 text-sm">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Resource cards */}
      <div className="container-main py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {RESOURCES.map((resource) => {
            const Icon = resource.icon;
            return (
              <div key={resource.title} className="card p-6 flex flex-col">
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colorMap[resource.color]}`}
                >
                  <Icon className="w-6 h-6" />
                </div>
                <h2 className="text-lg font-bold text-gray-900 mb-2">
                  {resource.title}
                </h2>
                <p className="text-sm text-gray-500 mb-4 flex-1">
                  {resource.description}
                </p>
                <ul className="space-y-1.5 mb-6">
                  {resource.features.map((f) => (
                    <li key={f} className="flex items-center gap-2 text-sm text-gray-600">
                      <CheckCircle2 className="w-4 h-4 text-green-500 flex-shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                <Link
                  href={resource.href}
                  className={`flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg font-semibold text-sm transition-colors ${btnColorMap[resource.color]}`}
                >
                  View {resource.title.split(" ").slice(-1)[0]}
                  <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            );
          })}
        </div>

        {/* Quick tips */}
        <div className="bg-amber-50 border border-amber-200 rounded-2xl p-8">
          <h2 className="text-xl font-bold text-gray-900 mb-2 text-center">
            💡 Expert JAMB Tips
          </h2>
          <p className="text-center text-gray-500 text-sm mb-6">
            Strategies from students who scored 300+
          </p>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            {TIPS.map(({ icon: Icon, tip }) => (
              <div key={tip} className="flex items-start gap-3">
                <div className="w-8 h-8 bg-amber-100 rounded-lg flex items-center justify-center flex-shrink-0 mt-0.5">
                  <Icon className="w-4 h-4 text-amber-600" />
                </div>
                <p className="text-sm text-gray-700">{tip}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
