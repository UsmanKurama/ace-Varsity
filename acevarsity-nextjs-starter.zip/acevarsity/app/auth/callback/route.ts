// app/auth/callback/route.ts
//
// 🧠 WHAT IS THIS FILE?
// This is an API route — a server-side endpoint.
// When a user signs in with Google, Google redirects them here
// with a special "code". This route exchanges that code for
// a real Supabase session (logs the user in).
//
// You don't need to understand everything here yet.
// Just know: this file is required for Google login to work.

import { createClient } from "@/lib/supabase/server";
import { NextResponse } from "next/server";

export async function GET(request: Request) {
  const { searchParams, origin } = new URL(request.url);
  const code = searchParams.get("code");
  const next = searchParams.get("next") ?? "/dashboard";

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      return NextResponse.redirect(`${origin}${next}`);
    }
  }

  // If something went wrong, send to login with error
  return NextResponse.redirect(`${origin}/auth/login?error=auth_failed`);
}
