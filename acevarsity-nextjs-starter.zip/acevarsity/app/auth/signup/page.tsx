"use client";
// app/auth/signup/page.tsx
// Matches your existing pages/auth/signup.html design

import { useState } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { Eye, EyeOff, Loader2 } from "lucide-react";
import toast from "react-hot-toast";
import { createClient } from "@/lib/supabase/client";

const NIGERIAN_UNIVERSITIES = [
  "University of Maiduguri (UNIMAID)",
  "Ahmadu Bello University (ABU) Zaria",
  "University of Lagos (UNILAG)",
  "University of Nigeria, Nsukka (UNN)",
  "Obafemi Awolowo University (OAU)",
  "University of Ibadan (UI)",
  "Bayero University Kano (BUK)",
  "University of Jos (UNIJOS)",
  "University of Ilorin (UNILORIN)",
  "Federal University of Technology Akure (FUTA)",
  "JAMB Aspirant (not yet in university)",
  "Other",
];

export default function SignupPage() {
  const router = useRouter();
  const [form, setForm] = useState({
    fullName: "",
    email: "",
    password: "",
    university: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  function update(field: string, value: string) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSignup(e: React.FormEvent) {
    e.preventDefault();
    if (!form.fullName || !form.email || !form.password) {
      toast.error("Please fill in all required fields.");
      return;
    }
    if (form.password.length < 8) {
      toast.error("Password must be at least 8 characters.");
      return;
    }
    setIsLoading(true);

    const supabase = createClient();
    const { error } = await supabase.auth.signUp({
      email: form.email,
      password: form.password,
      options: {
        data: {
          full_name:  form.fullName,
          university: form.university,
        },
        emailRedirectTo: `${window.location.origin}/auth/callback`,
      },
    });

    if (error) {
      toast.error(error.message);
      setIsLoading(false);
      return;
    }

    toast.success("Account created! Please check your email to verify your account.");
    router.push("/auth/login?message=check-email");
  }

  return (
    <div className="min-h-screen bg-[var(--bg-light)] flex items-center justify-center p-4 pt-24">
      <div className="w-full max-w-md">

        <div className="text-center mb-8">
          <h1 className="text-2xl font-bold text-[var(--primary-blue)]">
            Create Your Free Account
          </h1>
          <p className="text-[var(--slate-light)] mt-1">
            Join thousands of students acing their exams
          </p>
        </div>

        <div className="card p-8">
          <form onSubmit={handleSignup} className="space-y-5">

            <div>
              <label className="block text-sm font-semibold text-[var(--slate)] mb-1.5">
                Full Name <span className="text-[var(--error-red)]">*</span>
              </label>
              <input
                type="text"
                value={form.fullName}
                onChange={(e) => update("fullName", e.target.value)}
                placeholder="e.g. Amina Bello"
                required
                className="input"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[var(--slate)] mb-1.5">
                Email Address <span className="text-[var(--error-red)]">*</span>
              </label>
              <input
                type="email"
                value={form.email}
                onChange={(e) => update("email", e.target.value)}
                placeholder="youremail@example.com"
                required
                className="input"
              />
            </div>

            <div>
              <label className="block text-sm font-semibold text-[var(--slate)] mb-1.5">
                University
              </label>
              <select
                value={form.university}
                onChange={(e) => update("university", e.target.value)}
                className="input"
              >
                <option value="">Select your university</option>
                {NIGERIAN_UNIVERSITIES.map((u) => (
                  <option key={u} value={u}>{u}</option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-semibold text-[var(--slate)] mb-1.5">
                Password <span className="text-[var(--error-red)]">*</span>
              </label>
              <div className="relative">
                <input
                  type={showPassword ? "text" : "password"}
                  value={form.password}
                  onChange={(e) => update("password", e.target.value)}
                  placeholder="Min. 8 characters"
                  required
                  className="input pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[var(--slate-light)]"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="btn-primary w-full py-3.5"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                "Create Free Account"
              )}
            </button>

            <p className="text-xs text-center text-[var(--slate-light)]">
              By signing up, you agree to our{" "}
              <Link href="/pages/terms" className="text-[var(--primary-gold)] hover:underline">
                Terms of Service
              </Link>{" "}
              and{" "}
              <Link href="/pages/privacy" className="text-[var(--primary-gold)] hover:underline">
                Privacy Policy
              </Link>
            </p>
          </form>
        </div>

        <p className="text-center text-sm text-[var(--slate-light)] mt-6">
          Already have an account?{" "}
          <Link href="/auth/login" className="text-[var(--primary-gold)] font-semibold hover:underline">
            Sign in here
          </Link>
        </p>
        <div className="text-center mt-3">
          <Link href="/" className="text-xs text-[var(--slate-light)] hover:text-[var(--primary-gold)]">
            ← Back to Ace Varsity
          </Link>
        </div>
      </div>
    </div>
  );
}
