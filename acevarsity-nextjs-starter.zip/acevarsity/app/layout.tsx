// app/layout.tsx
//
// 🧠 WHAT IS THIS FILE?
// This is the ROOT LAYOUT. It wraps EVERY single page on your site.
// Think of it like a picture frame — every page is the picture inside it.
// The Navbar and Footer live here because they appear on every page.
//
// 🧠 WHAT IS "metadata"?
// This is SEO information — the title and description that Google shows
// in search results. You can override these on any individual page.

import type { Metadata } from "next";
import { Inter, Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";
import Navbar from "@/components/layout/Navbar";
import Footer from "@/components/layout/Footer";
import { Toaster } from "react-hot-toast";

// These are Google Fonts loaded efficiently by Next.js
const inter = Inter({
  subsets: ["latin"],
  variable: "--font-inter",
});

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
});

// This is the site-wide SEO metadata
export const metadata: Metadata = {
  title: {
    default: "Ace Varsity — Nigeria's #1 EdTech Platform",
    template: "%s | Ace Varsity", // Individual pages add their own title before this
  },
  description:
    "Access past questions, CBT practice exams, handouts, and study resources for all Nigerian universities. Join 10,000+ students acing their exams.",
  keywords: [
    "JAMB past questions",
    "CBT practice",
    "Nigerian university resources",
    "UTME preparation",
    "lecture handouts",
    "UNIMAID",
    "ABU Zaria",
  ],
  openGraph: {
    title: "Ace Varsity — Nigeria's #1 EdTech Platform",
    description:
      "Access past questions, CBT simulations, and study resources for Nigerian universities.",
    url: "https://acevarsity.com.ng",
    siteName: "Ace Varsity",
    images: [
      {
        url: "https://acevarsity.com.ng/images/og-image.jpg",
        width: 1200,
        height: 630,
      },
    ],
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "Ace Varsity — Nigeria's #1 EdTech Platform",
    description:
      "Access past questions, CBT practice, handouts & study resources for Nigerian universities.",
    images: ["https://acevarsity.com.ng/images/og-image.jpg"],
  },
};

// 🧠 WHAT IS "children"?
// In React, "children" means "whatever is placed inside this component".
// Here, every page on your site will be placed inside this layout
// as {children}. The Navbar sits above it, Footer below it.
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${inter.variable} ${plusJakarta.variable} font-sans antialiased bg-white text-gray-900`}
      >
        {/* Toaster shows popup notifications (e.g. "Subscribed successfully!") */}
        <Toaster position="top-right" />

        {/* Navbar appears on every page */}
        <Navbar />

        {/* This is where each page's content appears */}
        <main>{children}</main>

        {/* Footer appears on every page */}
        <Footer />
      </body>
    </html>
  );
}
