// app/not-found.tsx
// This page shows whenever someone visits a URL that doesn't exist
// e.g. acevarsity.com.ng/some-fake-page

import Link from "next/link";
import { BookOpen, ArrowLeft, Search } from "lucide-react";

export default function NotFound() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full text-center">

        {/* 404 illustration */}
        <div className="w-24 h-24 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6">
          <BookOpen className="w-12 h-12 text-blue-600" />
        </div>

        <h1 className="text-5xl font-bold text-gray-900 mb-2">404</h1>
        <h2 className="text-xl font-semibold text-gray-700 mb-3">
          Page Not Found
        </h2>
        <p className="text-gray-500 mb-8">
          This page doesn&apos;t exist or may have been moved.
          Let&apos;s get you back on track.
        </p>

        <div className="flex flex-col sm:flex-row gap-3 justify-center">
          <Link href="/" className="btn-primary">
            <ArrowLeft className="w-4 h-4" />
            Go Home
          </Link>
          <Link href="/resources" className="btn-secondary">
            <Search className="w-4 h-4" />
            Browse Resources
          </Link>
        </div>
      </div>
    </div>
  );
}
