"use server";
// lib/actions/auth.ts
//
// 🧠 WHAT ARE SERVER ACTIONS?
// Server Actions are functions that run on the server when called from
// a form or button click. They're the modern replacement for API routes
// for simple operations like signing out, updating profile, etc.
// The "use server" directive at the top tells Next.js this runs server-side.

import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

// Sign out the current user
export async function signOut() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/"); // Send to homepage after logout
}
