// lib/supabase/server.ts
//
// 🧠 This is the SERVER-SIDE Supabase client.
// It's used in:
// - Server Components (the default in Next.js App Router)
// - API Route handlers (/app/api/.../route.ts)
// - Server Actions
// - Middleware
//
// The server client can read cookies to identify who's logged in.
// This is how protected pages work: the server checks the cookie,
// confirms the user is authenticated, then sends the page.

import { createServerClient } from "@supabase/ssr";
import { cookies } from "next/headers";
import type { Database } from "@/types/database";

// 🧠 This is an "async" function because reading cookies in Next.js 15
// requires waiting (it's asynchronous). The "await" keyword pauses
// execution until the cookies are ready.
export async function createClient() {
  const cookieStore = await cookies();

  return createServerClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
    {
      cookies: {
        // These methods tell Supabase how to read and write cookies
        // in Next.js's cookie system
        getAll() {
          return cookieStore.getAll();
        },
        setAll(cookiesToSet) {
          try {
            cookiesToSet.forEach(({ name, value, options }) => {
              cookieStore.set(name, value, options);
            });
          } catch {
            // The setAll method is called from a Server Component,
            // which can't set cookies directly. This is fine if
            // you have middleware refreshing sessions.
          }
        },
      },
    }
  );
}
