// lib/supabase/client.ts
//
// 🧠 WHAT IS THIS FILE?
// This creates a Supabase "client" for use inside the browser (client components).
// A "client" is just the object that lets you talk to Supabase:
// - Query the database
// - Log users in/out
// - Upload files
//
// 🧠 WHY TWO SUPABASE FILES (client.ts and server.ts)?
// In Next.js, some code runs on the SERVER (Vercel's computers),
// and some runs in the BROWSER (the user's device).
// Supabase needs different setup for each environment.
// - client.ts: used in "use client" components (browser)
// - server.ts: used in server components and API routes (server)
//
// 🧠 WHERE DO THE ENVIRONMENT VARIABLES COME FROM?
// From your .env.local file! You'll create that file and add:
// NEXT_PUBLIC_SUPABASE_URL=https://yourproject.supabase.co
// NEXT_PUBLIC_SUPABASE_ANON_KEY=your-anon-key-here
//
// Variables starting with NEXT_PUBLIC_ are safe to use in the browser.
// Never put secret keys in NEXT_PUBLIC_ variables.

import { createBrowserClient } from "@supabase/ssr";
import type { Database } from "@/types/database";

// 🧠 This function is called "createClient" and returns a Supabase client.
// We call it every time we need to interact with Supabase in a browser component.
export function createClient() {
  return createBrowserClient<Database>(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
  );
}
