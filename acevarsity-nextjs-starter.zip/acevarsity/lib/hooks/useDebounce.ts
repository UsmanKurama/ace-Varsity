// lib/hooks/useDebounce.ts
// Delays updating a value until the user stops typing.
// Used in search inputs to avoid querying on every keystroke.
// Example: const debouncedSearch = useDebounce(searchTerm, 300);

import { useEffect, useState } from "react";

export function useDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useState<T>(value);

  useEffect(() => {
    const timer = setTimeout(() => setDebouncedValue(value), delay);
    return () => clearTimeout(timer);
  }, [value, delay]);

  return debouncedValue;
}
