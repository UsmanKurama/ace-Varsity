// lib/utils/formatters.ts
// Helper functions used throughout the app

// Format a number: 10000 → "10,000"
export function formatNumber(n: number): string {
  return new Intl.NumberFormat("en-NG").format(n);
}

// Format a date: "2024-01-15T..." → "January 15, 2024"
export function formatDate(dateString: string): string {
  return new Intl.DateTimeFormat("en-NG", {
    year: "numeric",
    month: "long",
    day: "numeric",
  }).format(new Date(dateString));
}

// Format seconds into "MM:SS" for the CBT timer
export function formatTime(seconds: number): string {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
}

// Turn a blog title into a URL slug: "Hello World" → "hello-world"
export function slugify(text: string): string {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9\s-]/g, "")
    .replace(/\s+/g, "-")
    .replace(/-+/g, "-")
    .trim();
}

// Get initials from a name: "Amina Yusuf" → "AY"
export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2);
}

// Calculate percentage: (7, 10) → "70%"
export function calcPercentage(score: number, total: number): string {
  if (total === 0) return "0%";
  return `${Math.round((score / total) * 100)}%`;
}

// Get a grade from a percentage
export function getGrade(percentage: number): {
  grade: string;
  color: string;
} {
  if (percentage >= 70) return { grade: "A", color: "text-green-600" };
  if (percentage >= 60) return { grade: "B", color: "text-blue-600" };
  if (percentage >= 50) return { grade: "C", color: "text-yellow-600" };
  if (percentage >= 45) return { grade: "D", color: "text-orange-600" };
  return { grade: "F", color: "text-red-600" };
}
