// lib/utils/cn.ts
//
// 🧠 WHAT IS THIS?
// This is a tiny helper function called "cn" (short for "className").
// In React/Tailwind, you often need to combine CSS class names
// conditionally. This function makes that clean and easy.
//
// EXAMPLE WITHOUT cn (messy):
// className={`btn ${isActive ? 'btn-active' : ''} ${disabled ? 'btn-disabled' : ''}`}
//
// EXAMPLE WITH cn (clean):
// className={cn("btn", isActive && "btn-active", disabled && "btn-disabled")}
//
// It also handles conflicts: if you have both "px-4" and "px-6",
// tailwind-merge will keep only "px-6" (the last one wins).

import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}
