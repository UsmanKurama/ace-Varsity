// components/layout/Footer.tsx
// 🧠 No "use client" here — this footer has no interactive elements,
// so it can be a Server Component. Faster and more SEO-friendly.

import Link from "next/link";
import { BookOpen, Mail, Twitter, Instagram, Facebook } from "lucide-react";

const FOOTER_LINKS = {
  Resources: [
    { label: "Past Questions", href: "/jamb-past-questions" },
    { label: "JAMB Materials", href: "/jamb-material" },
    { label: "Lecture Handouts", href: "/resources" },
    { label: "JAMB Syllabus", href: "/jamb-syllabus" },
    { label: "CBT Simulator", href: "/cbt/jamb-cbt" },
  ],
  Universities: [
    { label: "UNIMAID", href: "/resources?university=unimaid" },
    { label: "ABU Zaria", href: "/resources?university=abu" },
    { label: "UNILAG", href: "/resources?university=unilag" },
    { label: "UNN", href: "/resources?university=unn" },
    { label: "OAU", href: "/resources?university=oau" },
  ],
  Company: [
    { label: "About Us", href: "/about" },
    { label: "Blog", href: "/blog" },
    { label: "Careers", href: "/careers" },
    { label: "Contact", href: "/contact" },
    { label: "FAQ", href: "/faq" },
  ],
  Legal: [
    { label: "Privacy Policy", href: "/privacy" },
    { label: "Terms of Service", href: "/terms" },
    { label: "Cookie Policy", href: "/cookies" },
  ],
};

export default function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-400">
      <div className="container-main py-16">

        {/* Top section: Brand + Links */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-10 mb-12">

          {/* Brand column */}
          <div className="lg:col-span-1">
            <Link href="/" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <BookOpen className="w-5 h-5 text-white" />
              </div>
              <span className="text-white font-bold text-lg">Ace Varsity</span>
            </Link>
            <p className="text-sm leading-relaxed mb-6">
              Nigeria&apos;s #1 EdTech platform. Helping students ace their
              exams with verified past questions, CBT practice, and expert study
              materials.
            </p>
            {/* Social links */}
            <div className="flex items-center gap-3">
              <a
                href="https://twitter.com/acevarsity"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-600 transition-colors"
                aria-label="Twitter"
              >
                <Twitter className="w-4 h-4" />
              </a>
              <a
                href="https://instagram.com/acevarsity"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-pink-600 transition-colors"
                aria-label="Instagram"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a
                href="https://facebook.com/acevarsity"
                target="_blank"
                rel="noopener noreferrer"
                className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-blue-700 transition-colors"
                aria-label="Facebook"
              >
                <Facebook className="w-4 h-4" />
              </a>
              <a
                href="mailto:support@acevarsity.com.ng"
                className="w-9 h-9 bg-gray-800 rounded-lg flex items-center justify-center hover:bg-green-600 transition-colors"
                aria-label="Email"
              >
                <Mail className="w-4 h-4" />
              </a>
            </div>
          </div>

          {/* Link columns */}
          {Object.entries(FOOTER_LINKS).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-white font-semibold text-sm uppercase tracking-wider mb-4">
                {category}
              </h3>
              <ul className="space-y-2.5">
                {links.map((link) => (
                  <li key={link.href}>
                    <Link
                      href={link.href}
                      className="text-sm hover:text-white transition-colors"
                    >
                      {link.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom bar */}
        <div className="pt-8 border-t border-gray-800 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="text-sm">
            © {new Date().getFullYear()} Ace Varsity. All rights reserved.
          </p>
          <p className="text-sm">
            Made with ❤️ for Nigerian students 🇳🇬
          </p>
        </div>
      </div>
    </footer>
  );
}
