"use client";
// components/layout/Navbar.tsx
//
// 🧠 WHY "use client" AT THE TOP?
// The Navbar needs to respond to user interactions:
// - The mobile hamburger menu opens/closes when you tap it
// - The active link changes as you navigate
// Anything that needs to "react" to user actions or track state
// must be a "Client Component" — hence "use client" at the very top.
//
// Server Components (no "use client") run only on the server.
// Client Components run in the user's browser.

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Menu, X, BookOpen, ChevronDown } from "lucide-react";

// 🧠 WHAT IS THIS?
// This is a TypeScript "type" — it describes the shape of each nav item.
// TypeScript makes sure you never accidentally pass wrong data.
type NavItem = {
  label: string;
  href: string;
  children?: { label: string; href: string }[]; // Optional dropdown items
};

// This is all your navigation links in one place.
// Adding a new link? Just add it here — no need to touch HTML.
const NAV_ITEMS: NavItem[] = [
  {
    label: "Resources",
    href: "/resources",
  },
  {
    label: "JAMB",
    href: "/jamb-material",
    children: [
      { label: "JAMB Materials", href: "/jamb-material" },
      { label: "Past Questions", href: "/jamb-past-questions" },
      { label: "Syllabus", href: "/jamb-syllabus" },
      { label: "CBT Simulator", href: "/cbt/jamb-cbt" },
    ],
  },
  {
    label: "Blog",
    href: "/blog",
  },
];

export default function Navbar() {
  // 🧠 WHAT IS useState?
  // useState is a "hook" — a special function that lets a component
  // remember information between renders.
  // Here: isMenuOpen tracks whether the mobile menu is open or closed.
  // When you call setIsMenuOpen(true), React re-renders the component
  // with the new value, and the menu appears.
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  // 🧠 WHAT IS usePathname?
  // This hook gives you the current URL path.
  // e.g. on /resources it returns "/resources"
  // We use it to highlight the active nav link.
  const pathname = usePathname();

  // 🧠 WHAT IS useEffect?
  // useEffect runs code after the component appears on screen.
  // Here it adds a scroll listener — when you scroll down 10px,
  // the navbar gets a shadow to show it's floating above content.
  // The return function is a "cleanup" — it removes the listener
  // when you navigate away, preventing memory leaks.
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Close mobile menu when you navigate to a new page
  useEffect(() => {
    setIsMenuOpen(false);
    setOpenDropdown(null);
  }, [pathname]);

  // Check if a nav link is the currently active page
  const isActive = (href: string) =>
    pathname === href || pathname.startsWith(href + "/");

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 bg-white transition-shadow duration-300 ${
        isScrolled ? "shadow-md" : "border-b border-gray-100"
      }`}
    >
      <nav className="container-main">
        <div className="flex items-center justify-between h-16">

          {/* ── LOGO ─────────────────────────────────────────────── */}
          {/* 🧠 In Next.js, use <Link> instead of <a> for internal links.
              Link does client-side navigation — no full page reload, 
              making your app feel instant. */}
          <Link href="/" className="flex items-center gap-2 font-bold text-xl">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <span className="text-gray-900">
              Ace <span className="text-blue-600">Varsity</span>
            </span>
          </Link>

          {/* ── DESKTOP NAV LINKS ────────────────────────────────── */}
          <div className="hidden md:flex items-center gap-1">
            {NAV_ITEMS.map((item) => (
              <div key={item.href} className="relative">
                {item.children ? (
                  // Item with dropdown
                  <div>
                    <button
                      onClick={() =>
                        setOpenDropdown(
                          openDropdown === item.href ? null : item.href
                        )
                      }
                      className={`flex items-center gap-1 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                        isActive(item.href)
                          ? "text-blue-600 bg-blue-50"
                          : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                      }`}
                    >
                      {item.label}
                      <ChevronDown
                        className={`w-4 h-4 transition-transform ${
                          openDropdown === item.href ? "rotate-180" : ""
                        }`}
                      />
                    </button>

                    {/* Dropdown menu */}
                    {openDropdown === item.href && (
                      <div className="absolute top-full left-0 mt-1 w-52 bg-white rounded-xl shadow-lg border border-gray-200 py-1 z-50">
                        {item.children.map((child) => (
                          <Link
                            key={child.href}
                            href={child.href}
                            className="block px-4 py-2.5 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                          >
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    )}
                  </div>
                ) : (
                  // Regular link
                  <Link
                    href={item.href}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                      isActive(item.href)
                        ? "text-blue-600 bg-blue-50"
                        : "text-gray-600 hover:text-gray-900 hover:bg-gray-100"
                    }`}
                  >
                    {item.label}
                  </Link>
                )}
              </div>
            ))}
          </div>

          {/* ── AUTH BUTTONS (Desktop) ───────────────────────────── */}
          <div className="hidden md:flex items-center gap-3">
            <Link
              href="/auth/login"
              className="px-4 py-2 text-sm font-medium text-gray-700 hover:text-gray-900 transition-colors"
            >
              Log in
            </Link>
            <Link href="/auth/signup" className="btn-primary text-sm py-2">
              Get Started Free
            </Link>
          </div>

          {/* ── MOBILE MENU TOGGLE ──────────────────────────────── */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors"
            aria-label="Toggle menu"
          >
            {isMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>

        {/* ── MOBILE MENU ─────────────────────────────────────────── */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-gray-100 py-4 space-y-1">
            {NAV_ITEMS.map((item) => (
              <div key={item.href}>
                <Link
                  href={item.href}
                  className={`block px-4 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                    isActive(item.href)
                      ? "text-blue-600 bg-blue-50"
                      : "text-gray-700 hover:bg-gray-100"
                  }`}
                >
                  {item.label}
                </Link>
                {/* Mobile sub-links */}
                {item.children && (
                  <div className="ml-4 mt-1 space-y-1">
                    {item.children.map((child) => (
                      <Link
                        key={child.href}
                        href={child.href}
                        className="block px-4 py-2 text-sm text-gray-500 hover:text-blue-600 transition-colors"
                      >
                        → {child.label}
                      </Link>
                    ))}
                  </div>
                )}
              </div>
            ))}
            {/* Auth buttons on mobile */}
            <div className="pt-4 px-4 flex flex-col gap-2 border-t border-gray-100">
              <Link
                href="/auth/login"
                className="btn-secondary text-sm py-2.5 text-center"
              >
                Log in
              </Link>
              <Link
                href="/auth/signup"
                className="btn-primary text-sm py-2.5 text-center"
              >
                Get Started Free
              </Link>
            </div>
          </div>
        )}
      </nav>

      {/* Overlay to close dropdown when clicking outside */}
      {openDropdown && (
        <div
          className="fixed inset-0 z-40"
          onClick={() => setOpenDropdown(null)}
        />
      )}
    </header>
  );
}
