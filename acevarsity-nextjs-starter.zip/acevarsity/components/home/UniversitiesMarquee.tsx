// components/home/UniversitiesMarquee.tsx
// The scrolling university logos banner

export default function UniversitiesMarquee() {
  const universities = [
    "UNIMAID", "ABU Zaria", "UNILAG", "UNN", "OAU",
    "UI", "BUK", "UNIJOS", "JAMB Aspirants", "FUTA",
    "UNIABUJA", "UNIPORT", "UNIBEN", "LASU", "EKSU",
  ];

  // Duplicate the list so the marquee loops seamlessly
  const doubled = [...universities, ...universities];

  return (
    <section className="py-12 bg-gray-50 overflow-hidden border-y border-gray-200">
      <div className="container-main mb-6 text-center">
        <p className="text-sm font-medium text-gray-500 uppercase tracking-wider">
          Trusted by students from
        </p>
      </div>

      <div className="relative">
        {/* Fade edges */}
        <div className="absolute left-0 top-0 bottom-0 w-20 bg-gradient-to-r from-gray-50 to-transparent z-10" />
        <div className="absolute right-0 top-0 bottom-0 w-20 bg-gradient-to-l from-gray-50 to-transparent z-10" />

        {/* Scrolling track */}
        <div className="flex animate-marquee whitespace-nowrap">
          {doubled.map((uni, i) => (
            <div
              key={`${uni}-${i}`}
              className="inline-flex items-center mx-6 px-5 py-2.5 bg-white rounded-full border border-gray-200 shadow-sm text-sm font-semibold text-gray-700 flex-shrink-0"
            >
              🎓 {uni}
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
