"use client";
// components/home/StatsSection.tsx
//
// 🧠 WHY "use client"?
// This component animates numbers counting up (0 → 50,000).
// That animation requires JavaScript running in the browser,
// and it uses useState + useEffect to track whether the user
// has scrolled to see this section. That requires "use client".

import { useEffect, useRef, useState } from "react";

type Stat = {
  value: number;
  suffix: string;
  label: string;
  description: string;
};

const STATS: Stat[] = [
  {
    value: 50000,
    suffix: "+",
    label: "Past Questions",
    description: "Verified questions across all subjects",
  },
  {
    value: 15,
    suffix: "+",
    label: "CBT Exams",
    description: "Full mock exams with scoring",
  },
  {
    value: 20,
    suffix: "+",
    label: "Universities",
    description: "Nigerian institutions covered",
  },
  {
    value: 10000,
    suffix: "+",
    label: "Active Students",
    description: "And growing every day",
  },
];

// This is a helper function that counts from 0 to a target number
function useCountUp(target: number, duration: number, isVisible: boolean) {
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!isVisible) return;

    let start = 0;
    const step = target / (duration / 16); // 60fps

    const timer = setInterval(() => {
      start += step;
      if (start >= target) {
        setCount(target);
        clearInterval(timer);
      } else {
        setCount(Math.floor(start));
      }
    }, 16);

    return () => clearInterval(timer);
  }, [target, duration, isVisible]);

  return count;
}

// Individual stat item with count-up animation
function StatItem({ stat }: { stat: Stat }) {
  const ref = useRef<HTMLDivElement>(null);
  const [isVisible, setIsVisible] = useState(false);

  // 🧠 IntersectionObserver watches if an element is on screen.
  // When the stats section scrolls into view, we start the animation.
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect(); // Stop watching once seen
        }
      },
      { threshold: 0.3 }
    );

    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, []);

  const count = useCountUp(stat.value, 2000, isVisible);

  return (
    <div ref={ref} className="text-center p-6">
      <div className="text-4xl md:text-5xl font-bold text-blue-600 mb-2">
        {count.toLocaleString()}
        <span>{stat.suffix}</span>
      </div>
      <div className="text-lg font-semibold text-gray-900 mb-1">
        {stat.label}
      </div>
      <div className="text-sm text-gray-500">{stat.description}</div>
    </div>
  );
}

export default function StatsSection() {
  return (
    <section className="section-padding bg-white border-y border-gray-100">
      <div className="container-main">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-8">
          {STATS.map((stat) => (
            <StatItem key={stat.label} stat={stat} />
          ))}
        </div>
      </div>
    </section>
  );
}
