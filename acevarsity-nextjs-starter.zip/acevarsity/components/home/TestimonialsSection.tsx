// components/home/TestimonialsSection.tsx
// Server Component

import { Star } from "lucide-react";

const TESTIMONIALS = [
  {
    name: "Amina Yusuf",
    university: "UNIMAID, 300 Level",
    course: "Computer Science",
    avatar: "AY",
    rating: 5,
    text: "Ace Varsity helped me score 72% in my exams after months of struggling. The past questions are exactly what comes out in our university tests!",
  },
  {
    name: "Chidi Okafor",
    university: "UNN, 200 Level",
    course: "Law",
    avatar: "CO",
    rating: 5,
    text: "The CBT simulator is amazing. I practiced for 2 weeks before JAMB and scored 285. The questions are very similar to the real exam!",
  },
  {
    name: "Fatima Abdullahi",
    university: "ABU Zaria, 400 Level",
    course: "Medicine",
    avatar: "FA",
    rating: 5,
    text: "As a medical student, having access to verified past questions for all my courses saves me so much time. The handouts section is a lifesaver.",
  },
  {
    name: "Emeka Eze",
    university: "UNILAG, 100 Level",
    course: "Engineering",
    avatar: "EE",
    rating: 5,
    text: "I was totally lost before I found Ace Varsity. Now I know exactly what to read and how to prepare. My GPA went from 2.1 to 3.8 in one semester!",
  },
  {
    name: "Blessing Adeyemi",
    university: "OAU, 300 Level",
    course: "Economics",
    avatar: "BA",
    rating: 5,
    text: "The study community is what makes Ace Varsity special. I found a study group, and we share resources and motivate each other every day.",
  },
  {
    name: "Ibrahim Musa",
    university: "BUK, 200 Level",
    course: "Accounting",
    avatar: "IM",
    rating: 5,
    text: "Mobile-friendly and always available. I study during my commute, at night, anytime. Best educational investment I've made.",
  },
];

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex gap-0.5">
      {Array.from({ length: rating }).map((_, i) => (
        <Star key={i} className="w-4 h-4 fill-amber-400 text-amber-400" />
      ))}
    </div>
  );
}

export default function TestimonialsSection() {
  return (
    <section className="section-padding bg-white">
      <div className="container-main">

        {/* Header */}
        <div className="mb-14 text-center">
          <span className="inline-block px-4 py-1.5 bg-amber-100 text-amber-700 text-sm font-semibold rounded-full mb-4">
            Student Success Stories
          </span>
          <h2 className="section-title">What Our Students Say</h2>
          <p className="section-subtitle">
            Real stories from real students who aced their exams with Ace Varsity
          </p>
        </div>

        {/* Testimonials grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {TESTIMONIALS.map((t) => (
            <div key={t.name} className="card p-6 flex flex-col gap-4">

              {/* Stars */}
              <StarRating rating={t.rating} />

              {/* Quote */}
              <p className="text-gray-600 text-sm leading-relaxed flex-1">
                &ldquo;{t.text}&rdquo;
              </p>

              {/* Author */}
              <div className="flex items-center gap-3 pt-2 border-t border-gray-100">
                {/* Avatar (initials until we have real photos) */}
                <div className="w-10 h-10 rounded-full bg-blue-600 text-white flex items-center justify-center text-sm font-bold flex-shrink-0">
                  {t.avatar}
                </div>
                <div>
                  <div className="font-semibold text-gray-900 text-sm">
                    {t.name}
                  </div>
                  <div className="text-xs text-gray-500">
                    {t.university} · {t.course}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
