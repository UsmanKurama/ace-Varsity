"use client";
// components/home/NewsletterSection.tsx
// 🧠 "use client" because this has a form that submits

import { useState } from "react";
import toast from "react-hot-toast";
import { Mail, ArrowRight, Loader2 } from "lucide-react";

export default function NewsletterSection() {
  const [email, setEmail] = useState("");
  const [isLoading, setIsLoading] = useState(false);

  async function handleSubscribe(e: React.FormEvent) {
    e.preventDefault(); // Prevents page from reloading on form submit

    if (!email) return;
    setIsLoading(true);

    try {
      // 🧠 This calls our Next.js API route at /api/newsletter
      // You'll build that route in Phase 2 to save emails to Supabase
      const res = await fetch("/api/newsletter", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email }),
      });

      if (res.ok) {
        toast.success("🎉 Subscribed! Check your inbox for study tips.");
        setEmail("");
      } else {
        toast.error("Something went wrong. Please try again.");
      }
    } catch {
      toast.error("Something went wrong. Please try again.");
    } finally {
      setIsLoading(false);
    }
  }

  return (
    <section className="section-padding bg-blue-600">
      <div className="container-main">
        <div className="max-w-2xl mx-auto text-center">

          <div className="w-14 h-14 bg-white/20 rounded-2xl flex items-center justify-center mx-auto mb-6">
            <Mail className="w-7 h-7 text-white" />
          </div>

          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Get Study Tips & Updates
          </h2>
          <p className="text-blue-100 mb-8 text-lg">
            Subscribe for exam tips, scholarship alerts, and new study resources
            delivered straight to your inbox.
          </p>

          {/* Newsletter form */}
          <form onSubmit={handleSubscribe} className="flex flex-col sm:flex-row gap-3 max-w-md mx-auto">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email address"
              required
              className="flex-1 px-4 py-3 rounded-lg bg-white text-gray-900 placeholder-gray-400 focus:outline-none focus:ring-2 focus:ring-white/50"
            />
            <button
              type="submit"
              disabled={isLoading}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-amber-400 hover:bg-amber-500 text-gray-900 font-semibold rounded-lg transition-colors disabled:opacity-60"
            >
              {isLoading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : (
                <>
                  Subscribe
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          <p className="text-blue-200 text-sm mt-4">
            No spam, ever. Unsubscribe anytime.
          </p>
        </div>
      </div>
    </section>
  );
}
