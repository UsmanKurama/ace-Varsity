// components/home/FeaturesSection.tsx
// Server Component — just displays static content

import {
  BookOpen,
  FileText,
  Monitor,
  BarChart2,
  Users,
  Award,
  Smartphone,
  Headphones,
} from "lucide-react";

const FEATURES = [
  {
    icon: BookOpen,
    title: "50,000+ Past Questions",
    description:
      "Verified past questions from all Nigerian universities spanning 3+ years.",
    color: "bg-blue-100 text-blue-600",
  },
  {
    icon: FileText,
    title: "Lecture Handouts",
    description:
      "Curated notes and summaries from top-performing students across all faculties.",
    color: "bg-purple-100 text-purple-600",
  },
  {
    icon: Monitor,
    title: "CBT Simulator",
    description:
      "Real exam experience with timed tests and instant scoring.",
    color: "bg-green-100 text-green-600",
  },
  {
    icon: BarChart2,
    title: "Progress Tracking",
    description:
      "Monitor your performance and identify weak areas to focus on.",
    color: "bg-amber-100 text-amber-600",
  },
  {
    icon: Users,
    title: "Study Community",
    description:
      "Connect with peers, share resources, and learn together.",
    color: "bg-pink-100 text-pink-600",
  },
  {
    icon: Award,
    title: "Certificates",
    description:
      "Earn certificates for completed courses to showcase your achievements.",
    color: "bg-teal-100 text-teal-600",
  },
  {
    icon: Smartphone,
    title: "Mobile Optimized",
    description:
      "Study anytime, anywhere on any device — phone, tablet, or desktop.",
    color: "bg-indigo-100 text-indigo-600",
  },
  {
    icon: Headphones,
    title: "24/7 Support",
    description:
      "Dedicated support team always ready to help you succeed.",
    color: "bg-orange-100 text-orange-600",
  },
];

export default function FeaturesSection() {
  return (
    <section className="section-padding bg-gray-50">
      <div className="container-main">

        {/* Section Header */}
        <div className="mb-14 text-center">
          <span className="inline-block px-4 py-1.5 bg-blue-100 text-blue-700 text-sm font-semibold rounded-full mb-4">
            Why Ace Varsity?
          </span>
          <h2 className="section-title">
            Everything You Need to Excel
          </h2>
          <p className="section-subtitle">
            All in one place — from past questions to CBT practice to study community
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {FEATURES.map((feature) => {
            // 🧠 "const Icon = feature.icon" lets us use the imported
            // icon component dynamically. We capitalize it because
            // React requires component names to start with a capital letter.
            const Icon = feature.icon;
            return (
              <div
                key={feature.title}
                className="card p-6 group hover:-translate-y-1 transition-transform duration-200"
              >
                {/* Icon */}
                <div
                  className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${feature.color}`}
                >
                  <Icon className="w-6 h-6" />
                </div>

                {/* Text */}
                <h3 className="font-semibold text-gray-900 mb-2">
                  {feature.title}
                </h3>
                <p className="text-sm text-gray-500 leading-relaxed">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
