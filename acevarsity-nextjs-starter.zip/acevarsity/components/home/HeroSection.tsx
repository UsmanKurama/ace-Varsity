// components/home/HeroSection.tsx
// 🧠 Server Component — no interactivity needed here, pure display

import Link from "next/link";
import { ArrowRight, Star, Users, Shield, Smartphone } from "lucide-react";

const TRUST_BADGES = [
  { icon: Users, label: "Trusted by 10,000+ Students" },
  { icon: Shield, label: "100% Verified Content" },
  { icon: Smartphone, label: "Mobile Optimized" },
];

export default function HeroSection() {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">

      {/* Background gradient */}
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-amber-50 -z-10" />

      {/* Decorative blobs */}
      <div className="absolute top-20 right-0 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-40 -z-10" />
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-amber-100 rounded-full blur-3xl opacity-40 -z-10" />

      <div className="container-main">
        <div className="max-w-3xl mx-auto text-center">

          {/* Eyebrow tag */}
          <div className="inline-flex items-center gap-2 px-4 py-2 bg-blue-100 text-blue-700 rounded-full text-sm font-semibold mb-6">
            <Star className="w-4 h-4 fill-blue-600" />
            Nigeria&apos;s #1 EdTech Platform
          </div>

          {/* Main headline */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Your Gateway to{" "}
            <span className="text-blue-600 relative">
              Academic Excellence
              {/* Underline decoration */}
              <svg
                className="absolute -bottom-2 left-0 w-full"
                viewBox="0 0 300 12"
                fill="none"
                xmlns="http://www.w3.org/2000/svg"
              >
                <path
                  d="M1 9C75 3 150 1 299 9"
                  stroke="#2563eb"
                  strokeWidth="3"
                  strokeLinecap="round"
                  opacity="0.4"
                />
              </svg>
            </span>
          </h1>

          {/* Subheadline */}
          <p className="text-lg md:text-xl text-gray-600 mb-10 max-w-2xl mx-auto leading-relaxed">
            Access past questions, CBT simulations, handouts, and study
            resources from all Nigerian universities. Join thousands of students
            already acing their exams.
          </p>

          {/* CTA Buttons */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
            <Link href="/jamb-material" className="btn-primary text-base px-8 py-4 w-full sm:w-auto">
              JAMB Materials
              <ArrowRight className="w-5 h-5" />
            </Link>
            <Link href="/resources" className="btn-secondary text-base px-8 py-4 w-full sm:w-auto">
              Browse Resources
            </Link>
          </div>

          {/* Trust badges */}
          <div className="flex flex-wrap items-center justify-center gap-6">
            {TRUST_BADGES.map(({ icon: Icon, label }) => (
              <div
                key={label}
                className="flex items-center gap-2 text-sm text-gray-500"
              >
                <Icon className="w-4 h-4 text-blue-500" />
                <span>{label}</span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
