// components/resources/CourseGrid.tsx
// Server component — will fetch from Supabase in Phase 2
// For now shows placeholder/skeleton state

import { BookOpen, AlertCircle, MessageSquarePlus } from "lucide-react";
import Link from "next/link";

type Props = {
  filters: {
    faculty?: string;
    level?: string;
    search?: string;
  };
};

// 🧠 In Phase 2, this function will query Supabase:
// const courses = await supabase.from('courses').select('*').eq('faculty', filters.faculty)
// For now it returns an empty array to show the empty state UI
async function getCourses(filters: Props["filters"]) {
  // TODO Phase 2: Replace with real Supabase query
  return [];
}

export default async function CourseGrid({ filters }: Props) {
  const courses = await getCourses(filters);

  if (courses.length === 0) {
    return (
      <div className="space-y-4">
        {/* No results notice */}
        <div className="bg-white rounded-xl border border-gray-200 p-10 text-center">
          <div className="w-14 h-14 bg-blue-50 rounded-full flex items-center justify-center mx-auto mb-4">
            <BookOpen className="w-7 h-7 text-blue-400" />
          </div>
          <h3 className="font-semibold text-gray-900 mb-2">
            {filters.search || filters.faculty || filters.level
              ? "No courses match your filters"
              : "Courses Coming Soon"}
          </h3>
          <p className="text-sm text-gray-500 mb-6 max-w-sm mx-auto">
            {filters.search || filters.faculty || filters.level
              ? "Try adjusting your filters or search term."
              : "We're adding courses daily. Check back soon or request your course below."}
          </p>

          {/* Request course CTA */}
          <div className="inline-flex items-center gap-3 p-4 bg-blue-50 rounded-xl border border-blue-100">
            <AlertCircle className="w-5 h-5 text-blue-600 flex-shrink-0" />
            <div className="text-left">
              <p className="text-sm font-medium text-gray-900">
                Don&apos;t see your course?
              </p>
              <p className="text-xs text-gray-500">
                Let us know and we&apos;ll prioritize it.
              </p>
            </div>
            <Link
              href="/contact?subject=course-request"
              className="flex items-center gap-1 text-sm font-semibold text-blue-600 hover:text-blue-700 transition-colors whitespace-nowrap"
            >
              <MessageSquarePlus className="w-4 h-4" />
              Request Course
            </Link>
          </div>
        </div>

        {/* Skeleton placeholder cards (show what it will look like) */}
        <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
          {Array.from({ length: 6 }).map((_, i) => (
            <div
              key={i}
              className="bg-white rounded-xl border border-gray-200 p-5 animate-pulse"
            >
              <div className="h-4 bg-gray-200 rounded w-1/3 mb-3" />
              <div className="h-6 bg-gray-200 rounded w-3/4 mb-2" />
              <div className="h-4 bg-gray-200 rounded w-full mb-1" />
              <div className="h-4 bg-gray-200 rounded w-2/3 mb-4" />
              <div className="flex gap-2">
                <div className="h-6 bg-gray-200 rounded-full w-16" />
                <div className="h-6 bg-gray-200 rounded-full w-20" />
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  }

  // 🧠 This grid renders when real courses exist (Phase 2+)
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
      {courses.map((course: any) => (
        <div key={course.id} className="card p-5">
          {/* Course card content will go here */}
          <p>{course.title}</p>
        </div>
      ))}
    </div>
  );
}
