"use client";
// components/resources/ResourceFilter.tsx
// 🧠 "use client" because filters update the URL when changed

import { useRouter, usePathname } from "next/navigation";
import { Search, X } from "lucide-react";
import { useCallback, useState } from "react";

const FACULTIES = [
  "All Faculties",
  "Sciences",
  "Engineering",
  "Arts & Humanities",
  "Social Sciences",
  "Law",
  "Medicine & Health Sciences",
  "Agriculture",
  "Education",
  "Management Sciences",
];

const LEVELS = [
  { value: "", label: "All Levels" },
  { value: "100", label: "100 Level" },
  { value: "200", label: "200 Level" },
  { value: "300", label: "300 Level" },
  { value: "400", label: "400 Level" },
  { value: "500", label: "500 Level" },
  { value: "600", label: "600 Level" },
];

type Props = {
  currentParams: {
    faculty?: string;
    level?: string;
    search?: string;
  };
};

export default function ResourceFilter({ currentParams }: Props) {
  const router = useRouter();
  const pathname = usePathname();
  const [search, setSearch] = useState(currentParams.search ?? "");

  // 🧠 This function updates the URL when you change a filter.
  // The URL becomes /resources?faculty=sciences&level=300
  // Next.js reads those values on the server and shows matching courses.
  const updateFilter = useCallback(
    (key: string, value: string) => {
      const params = new URLSearchParams();

      // Carry over existing filters
      if (currentParams.faculty) params.set("faculty", currentParams.faculty);
      if (currentParams.level) params.set("level", currentParams.level);
      if (currentParams.search) params.set("search", currentParams.search);

      // Update or remove the changed filter
      if (value && value !== "All Faculties" && value !== "") {
        params.set(key, value);
      } else {
        params.delete(key);
      }

      router.push(`${pathname}?${params.toString()}`);
    },
    [currentParams, pathname, router]
  );

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    updateFilter("search", search);
  };

  const hasFilters =
    currentParams.faculty || currentParams.level || currentParams.search;

  return (
    <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-6">
      <h2 className="font-semibold text-gray-900">Filter Courses</h2>

      {/* Search */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Search Course
        </label>
        <form onSubmit={handleSearch} className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="e.g. MTH 201..."
            className="input pl-10 text-sm"
          />
        </form>
      </div>

      {/* Faculty filter */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Faculty
        </label>
        <select
          value={currentParams.faculty ?? "All Faculties"}
          onChange={(e) => updateFilter("faculty", e.target.value)}
          className="input text-sm"
        >
          {FACULTIES.map((f) => (
            <option key={f} value={f}>
              {f}
            </option>
          ))}
        </select>
      </div>

      {/* Level filter */}
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">
          Level
        </label>
        <div className="grid grid-cols-2 gap-2">
          {LEVELS.map(({ value, label }) => (
            <button
              key={label}
              onClick={() => updateFilter("level", value)}
              className={`px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
                (currentParams.level ?? "") === value
                  ? "bg-blue-600 text-white border-blue-600"
                  : "bg-white text-gray-700 border-gray-200 hover:border-blue-300"
              }`}
            >
              {label}
            </button>
          ))}
        </div>
      </div>

      {/* Clear filters */}
      {hasFilters && (
        <button
          onClick={() => router.push(pathname)}
          className="w-full flex items-center justify-center gap-2 text-sm text-red-600 hover:text-red-700 font-medium py-2"
        >
          <X className="w-4 h-4" />
          Clear All Filters
        </button>
      )}
    </div>
  );
}
