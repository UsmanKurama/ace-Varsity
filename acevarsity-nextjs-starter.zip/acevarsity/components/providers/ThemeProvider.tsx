"use client";
// components/providers/ThemeProvider.tsx
//
// 🧠 This replicates your existing dark mode system.
// Your current site saves dark mode preference in localStorage
// under the key "unimaidDarkMode" (from navbar.js).
// This provider reads that same key on load so the transition
// is seamless — students who already have dark mode won't notice any change.

import { createContext, useContext, useEffect, useState } from "react";

type Theme = "light" | "dark";

type ThemeContextType = {
  theme: Theme;
  toggleTheme: () => void;
  setTheme: (theme: Theme) => void;
};

const ThemeContext = createContext<ThemeContextType>({
  theme: "light",
  toggleTheme: () => {},
  setTheme: () => {},
});

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>("light");

  useEffect(() => {
    // Read existing preference — uses your SAME localStorage key
    const saved = localStorage.getItem("unimaidDarkMode");
    const isDark = saved === "enabled";
    setThemeState(isDark ? "dark" : "light");
    document.documentElement.setAttribute("data-theme", isDark ? "dark" : "");
    if (isDark) document.documentElement.classList.add("dark");
  }, []);

  function setTheme(t: Theme) {
    setThemeState(t);
    const isDark = t === "dark";
    document.documentElement.setAttribute("data-theme", isDark ? "dark" : "");
    document.documentElement.classList.toggle("dark", isDark);
    // Save with same key as before — backward compatible
    localStorage.setItem("unimaidDarkMode", isDark ? "enabled" : "disabled");
  }

  function toggleTheme() {
    setTheme(theme === "dark" ? "light" : "dark");
  }

  return (
    <ThemeContext.Provider value={{ theme, toggleTheme, setTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

// Custom hook — use this anywhere you need theme access:
// const { theme, toggleTheme } = useTheme();
export function useTheme() {
  return useContext(ThemeContext);
}
