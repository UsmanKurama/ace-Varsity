// next.config.ts
// This is Next.js configuration — settings that control how your app is built

import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Allow images from these external domains
  // Add more domains here as you use external images
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "*.supabase.co", // Supabase storage images
      },
      {
        protocol: "https",
        hostname: "acevarsity.com.ng", // Your existing images
      },
    ],
  },

  // Redirects: old HTML URLs → new clean URLs
  // This ensures people with old bookmarks still find the right page
  async redirects() {
    return [
      {
        source: "/resources.html",
        destination: "/resources",
        permanent: true, // 301 redirect — tells Google to update its index
      },
      {
        source: "/jamb-material.html",
        destination: "/jamb-material",
        permanent: true,
      },
      {
        source: "/jamb-syllabus.html",
        destination: "/jamb-syllabus",
        permanent: true,
      },
      {
        source: "/jamb-past-questions.html",
        destination: "/jamb-past-questions",
        permanent: true,
      },
      {
        source: "/faq.html",
        destination: "/faq",
        permanent: true,
      },
      {
        source: "/cbt/cbt-jamb.html",
        destination: "/cbt/jamb-cbt",
        permanent: true,
      },
    ];
  },
};

export default nextConfig;
