// types/database.ts
//
// 🧠 WHAT IS THIS FILE?
// This file defines the "shape" of your Supabase database in TypeScript.
// TypeScript uses this to warn you if you:
// - Try to access a column that doesn't exist
// - Pass the wrong type of data (e.g. a number where a string is expected)
//
// Think of it as a blueprint of your database tables.
// In Phase 2, you can auto-generate this file from Supabase using:
// npx supabase gen types typescript --project-id YOUR_PROJECT_ID > types/database.ts
//
// For now, this is a hand-written version to get started.

export type Database = {
  public: {
    Tables: {
      // ── PROFILES ──────────────────────────────────────────────────────
      // Extra user info beyond what Supabase Auth stores
      profiles: {
        Row: {
          id: string;
          user_id: string;
          full_name: string | null;
          avatar_url: string | null;
          university_id: string | null;
          department_id: string | null;
          level: number | null;
          is_premium: boolean;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          user_id: string;
          full_name?: string | null;
          avatar_url?: string | null;
          university_id?: string | null;
          department_id?: string | null;
          level?: number | null;
          is_premium?: boolean;
        };
        Update: {
          full_name?: string | null;
          avatar_url?: string | null;
          university_id?: string | null;
          department_id?: string | null;
          level?: number | null;
          is_premium?: boolean;
        };
      };

      // ── UNIVERSITIES ──────────────────────────────────────────────────
      universities: {
        Row: {
          id: string;
          name: string;
          abbreviation: string;
          state: string | null;
          logo_url: string | null;
          created_at: string;
        };
        Insert: {
          name: string;
          abbreviation: string;
          state?: string | null;
          logo_url?: string | null;
        };
        Update: {
          name?: string;
          abbreviation?: string;
          state?: string | null;
          logo_url?: string | null;
        };
      };

      // ── FACULTIES ─────────────────────────────────────────────────────
      faculties: {
        Row: {
          id: string;
          university_id: string;
          name: string;
          created_at: string;
        };
        Insert: {
          university_id: string;
          name: string;
        };
        Update: {
          name?: string;
        };
      };

      // ── DEPARTMENTS ───────────────────────────────────────────────────
      departments: {
        Row: {
          id: string;
          faculty_id: string;
          name: string;
          created_at: string;
        };
        Insert: {
          faculty_id: string;
          name: string;
        };
        Update: {
          name?: string;
        };
      };

      // ── COURSES ───────────────────────────────────────────────────────
      courses: {
        Row: {
          id: string;
          department_id: string | null;
          title: string;
          code: string;
          level: number;
          description: string | null;
          is_jamb: boolean;
          created_at: string;
        };
        Insert: {
          department_id?: string | null;
          title: string;
          code: string;
          level: number;
          description?: string | null;
          is_jamb?: boolean;
        };
        Update: {
          title?: string;
          code?: string;
          level?: number;
          description?: string | null;
          is_jamb?: boolean;
        };
      };

      // ── MATERIALS ─────────────────────────────────────────────────────
      materials: {
        Row: {
          id: string;
          course_id: string;
          type: "past_question" | "handout" | "note" | "syllabus";
          title: string;
          file_url: string | null;
          is_premium: boolean;
          downloads: number;
          created_at: string;
        };
        Insert: {
          course_id: string;
          type: "past_question" | "handout" | "note" | "syllabus";
          title: string;
          file_url?: string | null;
          is_premium?: boolean;
        };
        Update: {
          title?: string;
          file_url?: string | null;
          is_premium?: boolean;
        };
      };

      // ── QUESTIONS (for CBT) ───────────────────────────────────────────
      questions: {
        Row: {
          id: string;
          subject: string;
          year: number | null;
          question_text: string;
          option_a: string;
          option_b: string;
          option_c: string;
          option_d: string;
          correct_answer: "a" | "b" | "c" | "d";
          explanation: string | null;
          exam_type: "jamb" | "university" | "waec" | "neco";
          created_at: string;
        };
        Insert: {
          subject: string;
          year?: number | null;
          question_text: string;
          option_a: string;
          option_b: string;
          option_c: string;
          option_d: string;
          correct_answer: "a" | "b" | "c" | "d";
          explanation?: string | null;
          exam_type?: "jamb" | "university" | "waec" | "neco";
        };
        Update: {
          question_text?: string;
          explanation?: string | null;
        };
      };

      // ── CBT RESULTS ───────────────────────────────────────────────────
      cbt_results: {
        Row: {
          id: string;
          user_id: string;
          exam_type: string;
          subject: string | null;
          score: number;
          total: number;
          time_taken: number; // in seconds
          created_at: string;
        };
        Insert: {
          user_id: string;
          exam_type: string;
          subject?: string | null;
          score: number;
          total: number;
          time_taken: number;
        };
        Update: never; // Results should not be editable
      };

      // ── BLOG POSTS ────────────────────────────────────────────────────
      posts: {
        Row: {
          id: string;
          title: string;
          slug: string;
          excerpt: string | null;
          content: string;
          cover_image: string | null;
          author_id: string | null;
          published_at: string | null;
          created_at: string;
        };
        Insert: {
          title: string;
          slug: string;
          content: string;
          excerpt?: string | null;
          cover_image?: string | null;
          author_id?: string | null;
          published_at?: string | null;
        };
        Update: {
          title?: string;
          content?: string;
          excerpt?: string | null;
          cover_image?: string | null;
          published_at?: string | null;
        };
      };

      // ── NEWSLETTER SUBSCRIBERS ────────────────────────────────────────
      newsletter_subscribers: {
        Row: {
          id: string;
          email: string;
          subscribed_at: string;
        };
        Insert: {
          email: string;
        };
        Update: never;
      };
    };
  };
};
