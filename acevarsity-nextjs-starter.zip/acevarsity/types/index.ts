// types/index.ts
//
// 🧠 WHAT IS THIS FILE?
// These are TypeScript "types" — they describe the shape of your data objects.
// Instead of guessing what properties an object has, TypeScript tells you.
// If you try to access "course.titl" (typo), TypeScript will catch it immediately.

// Re-export database types for convenience
export type { Database } from "./database";

// ── University ─────────────────────────────────────────────────────────────
export type University = {
  id: string;
  name: string;
  abbreviation: string;
  state: string | null;
  logo_url: string | null;
};

// ── Faculty ────────────────────────────────────────────────────────────────
export type Faculty = {
  id: string;
  university_id: string;
  name: string;
};

// ── Department ─────────────────────────────────────────────────────────────
export type Department = {
  id: string;
  faculty_id: string;
  name: string;
};

// ── Course ─────────────────────────────────────────────────────────────────
export type Course = {
  id: string;
  department_id: string | null;
  title: string;
  code: string;
  level: number;
  description: string | null;
  is_jamb: boolean;
  // These are "joined" fields — they come from related tables
  department?: Department & {
    faculty?: Faculty & {
      university?: University;
    };
  };
  materials_count?: number;
};

// ── Material ───────────────────────────────────────────────────────────────
export type MaterialType = "past_question" | "handout" | "note" | "syllabus";

export type Material = {
  id: string;
  course_id: string;
  type: MaterialType;
  title: string;
  file_url: string | null;
  is_premium: boolean;
  downloads: number;
};

// ── Question (for CBT) ─────────────────────────────────────────────────────
export type ExamType = "jamb" | "university" | "waec" | "neco";
export type AnswerOption = "a" | "b" | "c" | "d";

export type Question = {
  id: string;
  subject: string;
  year: number | null;
  question_text: string;
  option_a: string;
  option_b: string;
  option_c: string;
  option_d: string;
  correct_answer: AnswerOption;
  explanation: string | null;
  exam_type: ExamType;
};

// ── CBT Session (in-progress exam state) ──────────────────────────────────
export type CBTSession = {
  questions: Question[];
  currentIndex: number;
  answers: Record<string, AnswerOption>; // questionId → chosen answer
  startTime: number;        // timestamp when exam started
  timeLimit: number;        // total seconds allowed
  isSubmitted: boolean;
};

// ── CBT Result ─────────────────────────────────────────────────────────────
export type CBTResult = {
  score: number;
  total: number;
  percentage: number;
  timeTaken: number; // seconds
  breakdown: {
    questionId: string;
    chosen: AnswerOption | null;
    correct: AnswerOption;
    isCorrect: boolean;
  }[];
};

// ── User Profile ───────────────────────────────────────────────────────────
export type Profile = {
  id: string;
  user_id: string;
  full_name: string | null;
  avatar_url: string | null;
  university_id: string | null;
  department_id: string | null;
  level: number | null;
  is_premium: boolean;
};

// ── Blog Post ──────────────────────────────────────────────────────────────
export type Post = {
  id: string;
  title: string;
  slug: string;
  excerpt: string | null;
  content: string;
  cover_image: string | null;
  published_at: string | null;
};

// ── API Response wrapper ───────────────────────────────────────────────────
// Used to give API responses a consistent shape
export type ApiResponse<T> =
  | { success: true; data: T }
  | { success: false; error: string };
